(اختیاری) فونت فارسی Vazirmatn

برای اینکه ظاهر برنامه و PDF دقیقاً با فونت وزیرمتن باشد:
1) فونت Vazirmatn را (لایسنس آزاد OFL) از صفحه‌ی github.com/rastikerdar/vazirmatn دانلود کنید.
2) فایل woff2 آن (نسخه‌ی variable یا Regular) را با نام  Vazirmatn.woff2  داخل همین پوشه (www/fonts) بگذارید.
3) بعد دستور  npx cap sync android  را بزنید و دوباره APK بسازید.

اگر این کار را نکنید هم برنامه کامل کار می‌کند و از فونت فارسی خود گوشی استفاده می‌شود.
