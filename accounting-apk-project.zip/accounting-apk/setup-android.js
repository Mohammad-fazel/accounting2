// بعد از "npx cap add android" یک بار اجرا کنید:  node setup-android.js
// مجوزهای ذخیره‌ی فایل و میکروفون را به AndroidManifest.xml اضافه می‌کند.
// روی GitHub (متغیر CI) از کلید امضای ثابت پروژه (debug.keystore) استفاده می‌کند تا APKهای بعدی روی هم نصب شوند.
const fs = require('fs'), os = require('os'), path = require('path');
const f = 'android/app/src/main/AndroidManifest.xml';
if (!fs.existsSync(f)) { console.error('فایل ' + f + ' پیدا نشد. اول دستور  npx cap add android  را اجرا کنید.'); process.exit(1); }
let x = fs.readFileSync(f, 'utf8');
if (!x.includes('requestLegacyExternalStorage')) x = x.replace('<application', '<application android:requestLegacyExternalStorage="true"');
for (const p of ['READ_EXTERNAL_STORAGE', 'WRITE_EXTERNAL_STORAGE']) {
  if (!x.includes('android.permission.' + p)) x = x.replace('<application', `<uses-permission android:name="android.permission.${p}" android:maxSdkVersion="32" />\n    <application`);
}
for (const p of ['RECORD_AUDIO', 'MODIFY_AUDIO_SETTINGS']) {
  if (!x.includes('android.permission.' + p)) x = x.replace('<application', `<uses-permission android:name="android.permission.${p}" />\n    <application`);
}
fs.writeFileSync(f, x);
console.log('OK: مجوزهای ذخیره‌ی فایل و میکروفون اضافه شد.');
if (process.env.CI && fs.existsSync('debug.keystore')) {
  const d = path.join(os.homedir(), '.android');
  fs.mkdirSync(d, {recursive: true});
  fs.copyFileSync('debug.keystore', path.join(d, 'debug.keystore'));
  console.log('OK: کلید امضای ثابت استفاده شد.');
}
